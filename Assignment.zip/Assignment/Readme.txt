JAVA ASSIGNMENT : Built Spring Boot project consisting of employee having fields  EmployeeName, PhoneNumber, Email, ReportsTo & ProfileImg. Project can perform CRUD Operations to add,delete,update,view all employees and proper validations has been done for API endpoints, Database used is MongoDb (Nosql), project hosted locally and endpoints documentation via Swagger. USED TECHNOLOGIES : Maven, SpringBoot, MongoDb, Swagger.
User sends The Employee information via APIs as Data Transfer Objects(DTOs) which are further getting saved as normal POJO entities in the database.

------------------
*** LEVELS COMPLETED : Entry Level as well as Intermediate Level ***
------------------

How to Run - 

Prerequisites:

Make sure you have Java JDK installed on your machine. Spring Boot requires Java 8 or later versions.
Install Maven.

Clone the Project:
Clone or download the project.

Using Maven You can run the Spring Boot Project.

Dependencies I used : Spring Boot Starter Web, Spring Boot Starter Mongodb,Spring Boot Starter Validation, Spring Boot Starter Test, ModelMapper, Open Api Documentation for Using APIs via Swagger.

How to set up database:

1. Install MongoDB Community Server:

2. Start MongoDB Service:

3. Access MongoDB Shell:

4. Create a Database:

5. Configure Spring Boot Application for MongoDB:
   Application Properties:
     # MongoDB connection properties
     spring.data.mongodb.host=localhost
     spring.data.mongodb.port=27017
     spring.data.mongodb.database=<name>

port i used : server.port = 9000
-------------------
Api Documentation for each route in JSON format:

1.Add Employee
Adds a new employee to the system.

Endpoint: POST /employees
Request Body:
{
  "id": 1,
  "employeeName": "xxx",
  "email": "xxx.xxx@xxx.com",
  "phoneNumber": "1234567890",
  "reportsTO": 2,
  "profileImage": "http://xxx.jpg"
}
Response (Status 201 Created) :
{
  "id": 1,
  "employeeName": "xxx",
  "email": "xxx.xxx@xxx.com",
  "phoneNumber": "1234567890",
  "reportsTO": 2,
  "profileImage": "http://xxx.jpg"
}


2. Get All Employees
Retrieves a list of all employees in the system.

Endpoint: GET /employees
Response (Status 200 OK):
[
  {
    "id": 1,
    "employeeName": "xxx",
    "email": "xxx.xxx@xxx.com",
    "phoneNumber": "1234567890",
    "reportsTO": 2,
    "profileImage": "http://xxx.jpg"
  },
  {
    "id": 2,
    "employeeName": "xxx2",
    "email": "xxx2.xxx@xxx.com",
    "phoneNumber": "1234567890",
    "reportsTO": 2,
    "profileImage": "http://xxx2.jpg"
  },
  ...
]


3.Delete Employee by ID
Deletes the employee with the specified ID from the system.

Endpoint: DELETE /employees/{id}
Path Variable:
{id}: The ID of the employee to be deleted.
Response (Status 204 No Content):
This endpoint does not return any content in the response body.


4.Update Employee by ID
Updates the employee with the specified ID and the Employee in the system.
(you have to give id as well as details as employeeDto to be modified)

Endpoint: PUT /employees/{id}
Path Variable:
{id}: The ID of the employee to be updated.

Path Variable: id,
Request Body:
{
    "id": 1,
    "employeeName": "xxx_Changed",
    "email": "xxx_Changed.xxx@xxx.com",
    "phoneNumber": "1234567890",
    "reportsTO": 2,
    "profileImage": "http://xxxChanged.jpg"
  }
Response (Status 200 OK):
{
    "id": 1,
    "employeeName": "xxx_Changed",
    "email": "xxx_Changed.xxx@xxx.com",
    "phoneNumber": "1234567890",
    "reportsTO": 2,
    "profileImage": "http://xxxChanged.jpg"
  }

5. Get All Employees with Pagination and Sorting

Endpoint : GET /paginatedAndSorted`

Request Parameters: page, size, name or email.

Response : list of employee paginated and sorted via name or email :
HTTP/1.1 200 OK

[
    {
        "id": 1,
        "employeeName": "xxx",
        "email": "xxx@example.com",
        "phoneNumber": "123-456-7890",
        "reportsTO": 2,
        "profileImage": "https://example.com/images/xxx.jpg"
    },
    {
        "id": 2,
        "employeeName": "xxx",
        "email": "xxx@example.com",
        "phoneNumber": "987-654-3210",
        "reportsTO": 3,
        "profileImage": "https://example.com/images/xxx.jpg"
    },
    ...
]


6. Get Nth Level Manager

Endpoint :`GET /{id}/{n}`

Path Variables : id,n

Response : 

HTTP/1.1 200 OK

{
    "id": 3,
    "employeeName": "xxx",
    "email": "xxx.xxx@example.com",
    "phoneNumber": "555-123-4567",
    "reportsTO": 1,
    "profileImage": "https://example.com/images/xxx.jpg"
}

-----------------------
Completed The Assignment with the learnings I had in past and by learning new concepts needed for this project via internet, hope it fulfills the requirements upto Intermediate Level :)
