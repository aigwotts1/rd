package com.abhinav.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abhinav.assignment.dto.EmployeeDTO;
import com.abhinav.assignment.service.EmployeeService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@RestController
@RequestMapping("/employees")
public class EmployeeRestController {

	@Autowired
	EmployeeService employeeService;
	
	@PostMapping
	public ResponseEntity<EmployeeDTO> addEmployee(@Valid @RequestBody EmployeeDTO employeeDto){
		return new ResponseEntity<> (employeeService.addEmployee(employeeDto),HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<EmployeeDTO>> getAllEmployees(){
		return new ResponseEntity<>(employeeService.getAllEmployees(),HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEmployeeById(@PathVariable @Valid @NotBlank(message = "Invalid Id") int id){
		employeeService.deleteEmployeeById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<EmployeeDTO> updateEmployeeById(@PathVariable @Valid @NotBlank(message = "Invalid Id") int id, @RequestBody @Valid EmployeeDTO employeeDto){
		return new ResponseEntity<>(employeeService.updateEmployeeById(id, employeeDto),HttpStatus.OK);
	}
	
	@GetMapping("/paginatedAndSorted")
	public ResponseEntity<List<EmployeeDTO>> getAllEmployeesUsingPaginationAndSorting(
			@Valid @Min(1) @RequestParam int page,
			@Valid @Min(1) @RequestParam int size,
			@Valid @Pattern(regexp = "^(name|email)$")@RequestParam String sortByNameOrEmail){
		return new ResponseEntity<>(employeeService.getAllEmployeesUsingPaginationAndSorting(page,size,sortByNameOrEmail),HttpStatus.OK);
	}	
	
	@GetMapping("/{id}/{n}")
	public ResponseEntity<EmployeeDTO> getNthLevelManager(@PathVariable int id,@PathVariable int n){
		return new ResponseEntity<>(employeeService.getNthLevelManager(n, id),HttpStatus.OK);
	}
}