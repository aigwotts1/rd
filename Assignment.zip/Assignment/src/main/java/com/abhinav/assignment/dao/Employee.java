package com.abhinav.assignment.dao;

import java.util.Objects;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Employees")
public class Employee {

	@Id
	private int id;
	
	private String employeeName;
	
	private String email;
	
	private String phoneNumber;
	
	private int reportsTO;
	
	private String profileImage;
	
	public Employee() {
	}
	
	public Employee(int id, String employeeName, String email, String phoneNumber, int reportsTO, String profileImage) {
		super();
		this.id = id;
		this.employeeName = employeeName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.reportsTO = reportsTO;
		this.profileImage = profileImage;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getReportsTO() {
		return reportsTO;
	}
	public void setReportsTO(int reportsTO) {
		this.reportsTO = reportsTO;
	}
	public String getProfileImage() {
		return profileImage;
	}
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", employeeName=" + employeeName + ", email=" + email + ", phoneNumber="
				+ phoneNumber + ", reportsTO=" + reportsTO + ", profileImage=" + profileImage + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(email, employeeName, id, phoneNumber, profileImage, reportsTO);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(email, other.email) && Objects.equals(employeeName, other.employeeName) && id == other.id
				&& Objects.equals(phoneNumber, other.phoneNumber) && Objects.equals(profileImage, other.profileImage)
				&& reportsTO == other.reportsTO;
	}
}
