package com.abhinav.assignment.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

public class EmployeeDTO {
	
	public EmployeeDTO() {
	}
	@Min(value = 1,message = "Id should be greater than 0")
	private int id;
	
	@NotEmpty(message = "Invalid EmployeeName")
	private String employeeName;
	
	@Email(message = "Invalid Email")
	private String email;
	
	@Pattern(regexp = "\\d{10}",message = "Phone Number should have 10 Digits")
	private String phoneNumber;

	@Min(message = "ReportsTo Must be Greater than 0", value = 0)
	private int reportsTO;
	
	@Pattern(regexp = "^(http(s?):\\/\\/)?([\\w-]+\\.)+[\\w-]+(:\\d+)?(\\/[\\w-]+)*\\/(?i)(.+\\.(jpeg|jpg|png|gif|bmp))$", message = "Profile Image should be in http://xxxx.jpg Format,example = https://www.example.com/images/photo.jpg")
	private String profileImage;
	
	public EmployeeDTO(int id, String employeeName, String email, String phoneNumber, int reportsTO, String profileImage) {
		super();
		this.id = id;
		this.employeeName = employeeName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.reportsTO = reportsTO;
		this.profileImage = profileImage;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getReportsTO() {
		return reportsTO;
	}
	public void setReportsTO(int reportsTO) {
		this.reportsTO = reportsTO;
	}
	public String getProfileImage() {
		return profileImage;
	}
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", employeeName=" + employeeName + ", email=" + email + ", phoneNumber="
				+ phoneNumber + ", reportsTO=" + reportsTO + ", profileImage=" + profileImage + "]";
	}
}