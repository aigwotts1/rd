package com.abhinav.assignment.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abhinav.assignment.dao.Employee;
import com.abhinav.assignment.dto.EmployeeDTO;
import com.abhinav.assignment.exception.EmployeeException;
import com.abhinav.assignment.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	private static final String EMPLOYEE_ALREADY_EXISTS = "Employee Already Exists !!!";
	private static final String MANAGER_NOT_FOUND = "ReportsTo Manager with such Id Not Found";
	private static final String EMPLOYEE_NOT_FOUND = "Employee Not Found";

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	ModelMapper modelMapper;

	public EmployeeDTO addEmployee(EmployeeDTO employeeDto) {

		if (employeeRepository.findById(employeeDto.getId()).isPresent()) {
			throw new EmployeeException(EMPLOYEE_ALREADY_EXISTS);
		}

		if (employeeDto.getReportsTO() != 0) {
			employeeRepository.findById(employeeDto.getReportsTO())
					.orElseThrow(() -> new EmployeeException(MANAGER_NOT_FOUND));
		}
		Employee employee = modelMapper.map(employeeDto, Employee.class);
		return modelMapper.map(employeeRepository.save(employee), EmployeeDTO.class);

	}

	public List<EmployeeDTO> getAllEmployees() {
		return employeeRepository.findAll().stream().map(employee -> modelMapper.map(employee, EmployeeDTO.class))
				.toList();
	}

	public void deleteEmployeeById(int id) {
		employeeRepository.deleteById(id);
	}

	public EmployeeDTO updateEmployeeById(int id, EmployeeDTO employeeDto) {
		employeeRepository.findById(id)
				.orElseThrow(() -> new EmployeeException(EMPLOYEE_NOT_FOUND));
		Employee employee = modelMapper.map(employeeDto,Employee.class);
		return modelMapper.map(employeeRepository.save(employee), EmployeeDTO.class);
	}

	public List<EmployeeDTO> getAllEmployeesUsingPaginationAndSorting(int page, int size, String sortBy) {
		int startIdx = (page - 1) * size;
		int endIdx = Math.min(startIdx + size, employeeRepository.findAll().size());

		List<Employee> sortedEmployees = employeeRepository.findAll().stream().sorted((e1, e2) -> {
			if (sortBy.equals("name")) {
				return e1.getEmployeeName().compareTo(e2.getEmployeeName());
			} else if (sortBy.equals("email")) {
				return e1.getEmail().compareTo(e2.getEmail());
			} else {
				return 0;
			}
		}).collect(Collectors.toList());

		List<EmployeeDTO> employees = sortedEmployees.stream()
				.map(employee -> modelMapper.map(employee, EmployeeDTO.class)).toList();
		return employees.subList(startIdx, endIdx);

	}

	public EmployeeDTO getNthLevelManager(int n, int id) {
		Employee employee = employeeRepository.findById(id)
				.orElseThrow(() -> new EmployeeException(EMPLOYEE_NOT_FOUND));
		for (int i = 1; i <= n; i++) {
			employee = employeeRepository.findById(employee.getReportsTO())
					.orElseThrow(() -> new EmployeeException(MANAGER_NOT_FOUND));
		}
		return modelMapper.map(employee, EmployeeDTO.class);
	}
}